
void vxl_static_test_function(int i)
{
}
