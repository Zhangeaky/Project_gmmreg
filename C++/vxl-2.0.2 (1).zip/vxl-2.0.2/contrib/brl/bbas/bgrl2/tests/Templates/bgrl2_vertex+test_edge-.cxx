#include <bgrl2/bgrl2_vertex.hxx>

#include "../test_edge.h"

BGRL2_VERTEX_INSTANTIATE(test_edge);
