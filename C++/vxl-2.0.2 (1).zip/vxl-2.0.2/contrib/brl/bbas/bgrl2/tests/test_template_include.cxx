#include <bgrl2/bgrl2_edge.hxx>
#include <bgrl2/bgrl2_graph.hxx>
#include <bgrl2/bgrl2_vertex.hxx>

int main() { return 0; }
