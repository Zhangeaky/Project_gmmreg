#include <bgrl2/bgrl2_edge.hxx>

#include "../test_node.h"

BGRL2_EDGE_INSTANTIATE(test_node);
