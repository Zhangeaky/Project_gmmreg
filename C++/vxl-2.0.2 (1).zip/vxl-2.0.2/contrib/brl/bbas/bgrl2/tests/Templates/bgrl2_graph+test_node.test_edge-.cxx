#include <bgrl2/bgrl2_graph.hxx>

#include "../test_node.h"
#include "../test_edge.h"

BGRL2_GRAPH_INSTANTIATE(test_node, test_edge);
