#ifndef test_node_sptr_h_
#define test_node_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class test_node;

typedef vbl_smart_ptr<test_node> test_node_sptr;

#endif // test_node_sptr_h_
