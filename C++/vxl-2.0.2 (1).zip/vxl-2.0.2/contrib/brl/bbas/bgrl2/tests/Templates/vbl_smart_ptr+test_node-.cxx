#include "../test_node.h"
#include "../test_edge.h"

#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(test_node);
