#ifndef test_edge_sptr_h_
#define test_edge_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class test_edge;

typedef vbl_smart_ptr<test_edge> test_edge_sptr;

#endif // test_edge_sptr_h_
