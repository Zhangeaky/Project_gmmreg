#include <testlib/testlib_register.h>

DECLARE( graph_test );

void
register_tests()
{
  REGISTER ( graph_test );
}

DEFINE_MAIN;
