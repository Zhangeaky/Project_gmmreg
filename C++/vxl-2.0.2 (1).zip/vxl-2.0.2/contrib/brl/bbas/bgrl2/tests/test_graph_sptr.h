#ifndef test_graph_sptr_h_
#define test_graph_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class test_graph;

typedef vbl_smart_ptr<test_graph> test_graph_sptr;

#endif // test_graph_sptr_h_
