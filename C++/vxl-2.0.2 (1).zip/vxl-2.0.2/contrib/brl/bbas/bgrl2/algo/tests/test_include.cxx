#include <bgrl2/algo/bgrl2_algs.h>

int main() { return 0; }
