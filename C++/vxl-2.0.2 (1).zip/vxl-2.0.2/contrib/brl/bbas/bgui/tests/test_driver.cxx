#include <testlib/testlib_register.h>

DECLARE( test_histogram );

void
register_tests()
{
  REGISTER ( test_histogram );
}

DEFINE_MAIN;
