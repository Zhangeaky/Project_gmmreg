#ifndef bgui_histogram_tableau_sptr_h_
#define bgui_histogram_tableau_sptr_h_

// this is a generated file.

#include <vgui/vgui_tableau_sptr.h>

class bgui_histogram_tableau;
typedef vgui_tableau_sptr_t<bgui_histogram_tableau> bgui_histogram_tableau_sptr;

#endif
