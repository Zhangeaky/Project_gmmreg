#ifndef bgui_vtol2D_tableau_sptr_h_
#define bgui_vtol2D_tableau_sptr_h_

#include <vgui/vgui_tableau_sptr.h>

class bgui_vtol2D_tableau;
typedef vgui_tableau_sptr_t<bgui_vtol2D_tableau> bgui_vtol2D_tableau_sptr;

#endif
