//if this file compiles, then the test passes
#include <bgrl/bgrl_edge_sptr.h>
#include <bgrl/bgrl_edge.h>
#include <bgrl/bgrl_vertex_sptr.h>
#include <bgrl/bgrl_vertex.h>
#include <bgrl/bgrl_graph_sptr.h>
#include <bgrl/bgrl_graph.h>
#include <bgrl/bgrl_search_func_sptr.h>
#include <bgrl/bgrl_search_func.h>

int main() { return 0; }
