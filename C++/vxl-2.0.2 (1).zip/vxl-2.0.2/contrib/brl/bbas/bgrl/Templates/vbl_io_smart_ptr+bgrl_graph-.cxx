#include <bgrl/bgrl_graph.h>
#include <vbl/io/vbl_io_smart_ptr.hxx>

VBL_IO_SMART_PTR_INSTANTIATE(bgrl_graph);
