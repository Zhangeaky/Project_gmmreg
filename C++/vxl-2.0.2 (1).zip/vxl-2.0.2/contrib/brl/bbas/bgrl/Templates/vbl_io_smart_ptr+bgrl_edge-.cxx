#include <bgrl/bgrl_edge.h>
#include <vsl/vsl_binary_loader.h>
#include <vbl/io/vbl_io_smart_ptr.hxx>

VBL_IO_SMART_PTR_INSTANTIATE(bgrl_edge);
