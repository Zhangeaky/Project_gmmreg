#include <bgrl/bgrl_graph.h>
#include <bgrl/bgrl_vertex.h>
#include <bgrl/bgrl_edge.h>
#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(bgrl_graph);
