// This is brl/bbas/bmsh3d/bmsh3d_he_mesh.cxx
//---------------------------------------------------------------------
#include "bmsh3d_he_mesh.h"
//:
// \file
// \brief 2-manifold mesh
//
// \author
//  MingChing Chang  Aug 22, 2005
//
// \verbatim
//  Modifications
//   <none>
// \endverbatim
//
//-------------------------------------------------------------------------
