#include <bmsh3d/algo/bmsh3d_fileio.h>
#include <bmsh3d/algo/bmsh3d_mesh_bnd.h>
#include <bmsh3d/algo/bmsh3d_mesh_tri.h>
#include <bmsh3d/algo/bmsh3d_mesh_triangulate.h>

int main() { return 0; }
