#include <bgui3d/bgui3d_tableau_sptr.h>
#include <bgui3d/bgui3d_viewer_tableau.h>
#include <bgui3d/bgui3d_file_io.h>
#include <bgui3d/bgui3d_examiner_tableau.h>
#include <bgui3d/bgui3d.h>
#include <bgui3d/bgui3d_project2d_tableau.h>
#include <bgui3d/bgui3d_translate_event.h>
#include <bgui3d/bgui3d_algo.h>
#include <bgui3d/bgui3d_viewer_tableau_sptr.h>
#include <bgui3d/bgui3d_fullviewer_tableau_sptr.h>
#include <bgui3d/bgui3d_examiner_tableau_sptr.h>
#include <bgui3d/bgui3d_fullviewer_tableau.h>
#include <bgui3d/bgui3d_project2d_tableau_sptr.h>
#include <bgui3d/bgui3d_examiner_slider_tableau.h>
#include <bgui3d/bgui3d_tableau.h>
#include <bgui3d/bgui3d_examiner_slider_tableau_sptr.h>

int main() { return 0; }
