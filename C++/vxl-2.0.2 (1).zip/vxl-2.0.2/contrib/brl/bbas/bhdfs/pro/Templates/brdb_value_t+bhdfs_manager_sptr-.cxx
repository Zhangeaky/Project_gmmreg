#include <brdb/brdb_value.hxx>
#include <bhdfs/bhdfs_manager.h>


BRDB_VALUE_INSTANTIATE(bhdfs_manager_sptr, "bhdfs_manager_sptr");
