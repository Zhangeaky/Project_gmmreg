#include <bhdfs/pro/bhdfs_processes.h>
#include <bhdfs/pro/bhdfs_register.h>

int main() { return 0; }
