#ifndef bhdfs_register_h_
#define bhdfs_register_h_

class bhdfs_register
{
 public:
  static void register_datatype();
  static void register_process();
};

#endif // bhdfs_register_h_
