#include <bhdfs/bhdfs_fstream.h>
#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(bhdfs_fstream);
