#include <bhdfs/bhdfs_manager.h>
#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(bhdfs_manager);
