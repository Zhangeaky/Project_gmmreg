#include <bhdfs/bhdfs_fstream.h>
#include <bhdfs/bhdfs_manager.h>
#include <bhdfs/bhdfs_vil_load.h>
#include <bhdfs/bhdfs_vil_save.h>
#include <bhdfs/bhdfs_vil_stream.h>

int main() { return 0; }
