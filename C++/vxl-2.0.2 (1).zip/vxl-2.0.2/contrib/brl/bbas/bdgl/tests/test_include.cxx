#include <bdgl/bdgl_curve_algs.h>
#include <bdgl/bdgl_curve_region.h>
#include <bdgl/bdgl_peano_curve.h>
#include <bdgl/bdgl_region_algs.h>

int main() { return 0; }
