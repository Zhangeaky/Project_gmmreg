#include <testlib/testlib_register.h>


DECLARE(test_bjson );

void
register_tests()
{
  REGISTER(test_bjson  );
}

DEFINE_MAIN;
