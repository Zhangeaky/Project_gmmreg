#include <baio/baio.h>

int main() { return 0; }
