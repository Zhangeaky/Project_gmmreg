#include <testlib/testlib_register.h>

DECLARE(test_array_dynamic_prg);


void
register_tests()
{
  REGISTER(test_array_dynamic_prg);
}

DEFINE_MAIN;
