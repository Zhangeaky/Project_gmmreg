#include <bdpg/bdpg_node.h>
#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(bdpg_node);
