#include <bil/algo/bil_finite_second_differences.hxx>
BIL_FINITE_SECOND_DIFFERENCES_INSTANTIATE(float);
