#include <bil/algo/bil_detect_ridges.hxx>
BIL_DETECT_RIDGES_INSTANTIATE(float);
