#include <bil/algo/bil_harr_wavelet_transform.hxx>

BIL_HARR_WAVELET_TRANSFORM_INSTANTIATE(float);
