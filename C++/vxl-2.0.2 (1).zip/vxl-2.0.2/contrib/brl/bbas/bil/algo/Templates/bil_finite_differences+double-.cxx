#include <bil/algo/bil_finite_differences.hxx>
BIL_FINITE_DIFFERENCES_INSTANTIATE(double);
