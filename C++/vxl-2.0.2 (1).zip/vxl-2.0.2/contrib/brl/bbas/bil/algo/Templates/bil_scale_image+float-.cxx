#include <bil/algo/bil_scale_image.hxx>

BIL_SCALE_IMAGE_INSTANTIATE(float);
