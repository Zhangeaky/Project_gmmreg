#include <bil/algo/bil_perform_tensor_decomposition.hxx>
BIL_PERFORM_TENSOR_DECOMPOSITION_INSTANTIATE(float);
