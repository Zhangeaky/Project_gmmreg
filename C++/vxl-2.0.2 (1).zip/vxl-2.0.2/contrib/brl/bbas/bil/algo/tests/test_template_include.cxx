#include <bil/algo/bil_detect_ridges.hxx>
#include <bil/algo/bil_finite_differences.hxx>
#include <bil/algo/bil_finite_second_differences.hxx>
#include <bil/algo/bil_harr_wavelet_transform.hxx>
#include <bil/algo/bil_perform_tensor_decomposition.hxx>
#include <bil/algo/bil_scale_image.hxx>

int main() { return 0; }
