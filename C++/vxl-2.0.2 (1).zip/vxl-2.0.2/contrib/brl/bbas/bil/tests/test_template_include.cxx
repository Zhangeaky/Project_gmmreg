#include <bil/bil_bounded_image_view.hxx>

int main() { return 0; }
