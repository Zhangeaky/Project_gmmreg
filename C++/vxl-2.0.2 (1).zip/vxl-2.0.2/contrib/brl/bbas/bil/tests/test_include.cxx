#include <bil/bil_arf_image_istream.h>
#include <bil/bil_bounded_image_view.h>
#include <bil/bil_math.h>
#include <bil/bil_raw_image_istream.h>

int main() { return 0; }
