#include <testlib/testlib_register.h>

DECLARE( test_bkml );

void
register_tests()
{
  REGISTER( test_bkml );
}

DEFINE_MAIN;
