#include <bkml/bkml_parser.h>
#include <bkml/bkml_write.h>

int main() { return 0; }
