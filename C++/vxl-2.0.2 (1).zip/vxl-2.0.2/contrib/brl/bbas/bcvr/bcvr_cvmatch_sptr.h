#ifndef bcvr_cvmatch_sptr_h
#define bcvr_cvmatch_sptr_h

class bcvr_cvmatch;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<bcvr_cvmatch> bcvr_cvmatch_sptr;

#endif // bcvr_cvmatch_sptr_h
