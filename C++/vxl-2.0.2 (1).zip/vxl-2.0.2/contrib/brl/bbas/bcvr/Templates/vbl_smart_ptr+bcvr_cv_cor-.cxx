#include <bcvr/bcvr_cv_cor.h>
#include <vsol/vsol_polygon_2d.h>
#include <vsol/vsol_box_2d.h>

#include <vbl/vbl_smart_ptr.hxx>

VBL_SMART_PTR_INSTANTIATE(bcvr_cv_cor);
