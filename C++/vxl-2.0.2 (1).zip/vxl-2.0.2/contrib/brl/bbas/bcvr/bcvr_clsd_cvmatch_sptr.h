#ifndef bcvr_clsd_cvmatch_sptr_h
#define bcvr_clsd_cvmatch_sptr_h

class bcvr_clsd_cvmatch;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<bcvr_clsd_cvmatch> bcvr_clsd_cvmatch_sptr;

#endif // bcvr_clsd_cvmatch_sptr_h
