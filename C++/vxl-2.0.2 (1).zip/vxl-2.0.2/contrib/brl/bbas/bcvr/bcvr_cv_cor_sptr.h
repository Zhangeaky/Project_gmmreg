#ifndef bcvr_cv_cor_sptr_h
#define bcvr_cv_cor_sptr_h

class bcvr_cv_cor;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<bcvr_cv_cor> bcvr_cv_cor_sptr;

#endif // bcvr_cv_cor_sptr_h
