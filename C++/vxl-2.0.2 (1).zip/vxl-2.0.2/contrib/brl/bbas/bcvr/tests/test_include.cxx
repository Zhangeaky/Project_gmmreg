#include <bcvr/bcvr_cvmatch.h>
#include <bcvr/bcvr_cvmatch_sptr.h>
#include <bcvr/bcvr_clsd_cvmatch.h>
#include <bcvr/bcvr_clsd_cvmatch_sptr.h>
#include <bcvr/bcvr_cv_cor.h>
#include <bcvr/bcvr_cv_cor_sptr.h>



int main() { return 0; }
