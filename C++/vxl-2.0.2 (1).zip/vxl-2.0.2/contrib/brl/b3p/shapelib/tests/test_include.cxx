#include <b3p/shapelib/shapefil.h>

int main() { return 0; }
