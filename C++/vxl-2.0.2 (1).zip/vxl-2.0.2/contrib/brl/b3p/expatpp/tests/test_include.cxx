#include <b3p/expatpp/expatpp.h>
#include <b3p/expatpp/expatpplib.h>

int main() { return 0; }
