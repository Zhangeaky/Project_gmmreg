#ifndef bsta_histogram_sptr_h_ 
#define bsta_histogram_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class bsta_histogram_base;
typedef vbl_smart_ptr<bsta_histogram_base> bsta_histogram_sptr;

#endif
