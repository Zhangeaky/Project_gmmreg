#ifndef bsta_joint_histogram_sptr_h_ 
#define bsta_joint_histogram_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class bsta_joint_histogram_base;
typedef vbl_smart_ptr<bsta_joint_histogram_base> bsta_joint_histogram_sptr;

#endif
