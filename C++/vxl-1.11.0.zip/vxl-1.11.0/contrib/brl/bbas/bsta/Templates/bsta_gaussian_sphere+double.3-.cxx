#include <bsta/bsta_gaussian_sphere.txx>

BSTA_GAUSSIAN_SPHERE_INSTANTIATE(double, 3);
