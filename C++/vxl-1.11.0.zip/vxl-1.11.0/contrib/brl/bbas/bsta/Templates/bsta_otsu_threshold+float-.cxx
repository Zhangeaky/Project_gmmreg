#include <bsta/bsta_otsu_threshold.txx>
BSTA_OTSU_THRESHOLD_INSTANTIATE(float);
