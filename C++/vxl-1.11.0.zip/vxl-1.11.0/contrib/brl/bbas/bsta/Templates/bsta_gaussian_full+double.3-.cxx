#include <bsta/bsta_gaussian_full.txx>

BSTA_GAUSSIAN_FULL_INSTANTIATE(double, 3);
