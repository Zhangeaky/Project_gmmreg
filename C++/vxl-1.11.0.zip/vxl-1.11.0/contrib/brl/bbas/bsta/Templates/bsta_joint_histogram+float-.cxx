#include <bsta/bsta_joint_histogram.txx>
BSTA_JOINT_HISTOGRAM_INSTANTIATE(float);
