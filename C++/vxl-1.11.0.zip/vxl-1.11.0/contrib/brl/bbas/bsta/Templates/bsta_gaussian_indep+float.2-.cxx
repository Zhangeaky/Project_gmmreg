#include <bsta/bsta_gaussian_indep.txx>

BSTA_GAUSSIAN_INDEP_INSTANTIATE(float, 2);
