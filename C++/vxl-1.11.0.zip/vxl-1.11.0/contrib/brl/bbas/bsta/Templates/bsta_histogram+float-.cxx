#include <bsta/bsta_histogram.txx>
BSTA_HISTOGRAM_INSTANTIATE(float);
