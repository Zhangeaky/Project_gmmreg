#include <bsta/bsta_joint_histogram_base.h>
#include <vbl/vbl_smart_ptr.txx>

VBL_SMART_PTR_INSTANTIATE(bsta_joint_histogram_base);
