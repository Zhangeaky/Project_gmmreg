#include <bdpg/bdpg_node.h>
#include <vbl/vbl_smart_ptr.txx>

VBL_SMART_PTR_INSTANTIATE(bdpg_node);
