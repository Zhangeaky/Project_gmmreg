#include <bdpg/bdpg_node_sptr.h>
#include <bdpg/bdpg_node.h>
#include <bdpg/bdpg_array_dynamic_prg.h>

int main() { return 0; }
