#include <bgrl/bgrl_edge_sptr.h>
#include <vbl/io/vbl_io_smart_ptr.h>
#include <vsl/vsl_set_io.txx>

VSL_SET_IO_INSTANTIATE(bgrl_edge_sptr);

