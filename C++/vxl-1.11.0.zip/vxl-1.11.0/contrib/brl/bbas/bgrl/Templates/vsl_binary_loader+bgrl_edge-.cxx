#include <bgrl/bgrl_edge.h>
#include <vsl/vsl_binary_loader.txx>
 
VSL_BINARY_LOADER_INSTANTIATE(bgrl_edge);
