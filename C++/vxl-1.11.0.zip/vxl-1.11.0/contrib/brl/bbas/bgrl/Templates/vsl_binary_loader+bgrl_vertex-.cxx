#include <bgrl/bgrl_vertex.h>
#include <vsl/vsl_binary_loader.txx>
 
VSL_BINARY_LOADER_INSTANTIATE(bgrl_vertex);
