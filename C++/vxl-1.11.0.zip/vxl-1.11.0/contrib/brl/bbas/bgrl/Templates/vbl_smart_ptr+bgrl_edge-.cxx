#include <bgrl/bgrl_edge.h>
#include <bgrl/bgrl_vertex.h>
#include <vbl/vbl_smart_ptr.txx>

VBL_SMART_PTR_INSTANTIATE(bgrl_edge);
