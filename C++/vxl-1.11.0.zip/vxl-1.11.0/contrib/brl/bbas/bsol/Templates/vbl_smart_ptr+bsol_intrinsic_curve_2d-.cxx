#include <bsol/bsol_intrinsic_curve_2d.h>
#include <vsol/vsol_box_2d.h>
#include <vbl/vbl_smart_ptr.txx>

VBL_SMART_PTR_INSTANTIATE(bsol_intrinsic_curve_2d);
