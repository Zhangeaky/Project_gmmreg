#include <bsol/bsol_intrinsic_curve_3d.h>
#include <vsol/vsol_box_3d.h>
#include <vbl/vbl_smart_ptr.txx>

VBL_SMART_PTR_INSTANTIATE(bsol_intrinsic_curve_3d);
