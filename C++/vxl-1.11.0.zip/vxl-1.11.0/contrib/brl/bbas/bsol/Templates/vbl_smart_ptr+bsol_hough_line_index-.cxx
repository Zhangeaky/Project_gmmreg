#include <bsol/bsol_hough_line_index.h>
#include <vbl/vbl_smart_ptr.txx>
 
VBL_SMART_PTR_INSTANTIATE(bsol_hough_line_index);

