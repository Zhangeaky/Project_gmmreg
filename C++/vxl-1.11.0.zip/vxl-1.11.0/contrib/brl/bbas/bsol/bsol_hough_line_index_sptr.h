#ifndef bsol_hough_line_index_sptr_h
#define bsol_hough_line_index_sptr_h

class bsol_hough_line_index;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<bsol_hough_line_index> bsol_hough_line_index_sptr;

#endif // bsol_hough_line_index_sptr_h
