#include <bsol/bsol_hough_line_index_sptr.h>
#include <bsol/bsol_intrinsic_curve_2d_sptr.h>
#include <bsol/bsol_intrinsic_curve_3d_sptr.h>

#include <bsol/bsol_algs.h>
#include <bsol/bsol_distance_histogram.h>
#include <bsol/bsol_hough_line_index.h>
#include <bsol/bsol_intrinsic_curve_2d.h>
#include <bsol/bsol_intrinsic_curve_3d.h>
#include <bsol/bsol_point_index_2d.h>
#include <bsol/bsol_point_index_3d.h>

int main() { return 0; }
