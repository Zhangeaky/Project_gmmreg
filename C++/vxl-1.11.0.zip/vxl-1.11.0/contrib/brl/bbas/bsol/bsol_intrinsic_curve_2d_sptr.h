#ifndef bsol_intrinsic_curve_2d_sptr_h
#define bsol_intrinsic_curve_2d_sptr_h

class bsol_intrinsic_curve_2d;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<bsol_intrinsic_curve_2d> bsol_intrinsic_curve_2d_sptr;

#endif // bsol_intrinsic_curve_2d_sptr_h
