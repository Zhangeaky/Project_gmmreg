#ifndef bgui_range_adjuster_tableau_sptr_h_
#define bgui_range_adjuster_tableau_sptr_h_

// this is a generated file.

#include <vgui/vgui_easy2D_tableau_sptr.h>

class bgui_range_adjuster_tableau;
typedef vgui_tableau_sptr_t<bgui_range_adjuster_tableau> bgui_range_adjuster_tableau_sptr;

#endif
