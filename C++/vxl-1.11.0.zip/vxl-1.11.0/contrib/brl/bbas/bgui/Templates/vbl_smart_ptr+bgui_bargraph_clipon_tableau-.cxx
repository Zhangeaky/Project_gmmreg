#include <vbl/vbl_smart_ptr.txx>
#include <vgui/vgui_tableau.h>
#include <vgui/vgui_style.h>
#include <bgui/bgui_bargraph_clipon_tableau.h>
VBL_SMART_PTR_INSTANTIATE(bgui_bargraph_clipon_tableau);
