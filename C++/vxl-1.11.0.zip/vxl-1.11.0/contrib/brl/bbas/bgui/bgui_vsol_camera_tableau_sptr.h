#ifndef bgui_vsol_camera_tableau_sptr_h_
#define bgui_vsol_camera_tableau_sptr_h_

#include <vgui/vgui_tableau_sptr.h>

class bgui_vsol_camera_tableau;
typedef vgui_tableau_sptr_t<bgui_vsol_camera_tableau> bgui_vsol_camera_tableau_sptr;

#endif
