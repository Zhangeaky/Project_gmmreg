#include <bgui/bgui_bargraph_clipon_tableau.h>
#include <bgui/bgui_bargraph_clipon_tableau_sptr.h>
#include <bgui/bgui_bmrf_soview2D.h>
#include <bgui/bgui_graph_tableau.h>
#include <bgui/bgui_graph_tableau_sptr.h>
#include <bgui/bgui_histogram_tableau.h>
#include <bgui/bgui_histogram_tableau_sptr.h>
#include <bgui/bgui_image_tableau.h>
#include <bgui/bgui_image_tableau_sptr.h>
#include <bgui/bgui_image_utils.h>
#include <bgui/bgui_picker_tableau.h>
#include <bgui/bgui_picker_tableau_sptr.h>
#include <bgui/bgui_range_adjuster_tableau.h>
#include <bgui/bgui_range_adjuster_tableau_sptr.h>
#include <bgui/bgui_selector_tableau.h>
#include <bgui/bgui_selector_tableau_sptr.h>
#include <bgui/bgui_vsol2D_tableau.h>
#include <bgui/bgui_vsol2D_tableau_sptr.h>
#include <bgui/bgui_vsol_camera_tableau.h>
#include <bgui/bgui_vsol_camera_tableau_sptr.h>
#include <bgui/bgui_vsol_soview2D.h>
#include <bgui/bgui_vtol2D_rubberband_client.h>
#include <bgui/bgui_vtol2D_tableau.h>
#include <bgui/bgui_vtol2D_tableau_sptr.h>
#include <bgui/bgui_vtol_soview2D.h>

int main() { return 0; }
