#ifndef bgui_bargraph_clipon_tableau_sptr_h_
#define bgui_bargraph_clipon_tableau_sptr_h_

#include <vbl/vbl_smart_ptr.h>

class bgui_bargraph_clipon_tableau;
typedef vbl_smart_ptr<bgui_bargraph_clipon_tableau> bgui_bargraph_clipon_tableau_sptr;

#endif
