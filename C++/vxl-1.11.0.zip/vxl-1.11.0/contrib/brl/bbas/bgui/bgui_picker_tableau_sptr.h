#ifndef bgui_picker_tableau_sptr_h_
#define bgui_picker_tableau_sptr_h_

#include <vgui/vgui_tableau_sptr.h>

class bgui_picker_tableau;
typedef vgui_tableau_sptr_t<bgui_picker_tableau> bgui_picker_tableau_sptr;

#endif
