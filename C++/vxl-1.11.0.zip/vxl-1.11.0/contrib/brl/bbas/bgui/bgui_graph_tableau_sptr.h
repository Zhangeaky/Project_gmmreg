#ifndef bgui_graph_tableau_sptr_h_
#define bgui_graph_tableau_sptr_h_

// this is a generated file.

#include <vgui/vgui_easy2D_tableau_sptr.h>

class bgui_graph_tableau;
typedef vgui_tableau_sptr_t<bgui_graph_tableau> bgui_graph_tableau_sptr;

#endif
