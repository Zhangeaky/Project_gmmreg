#include <bmsh3d/vis/bmsh3d_vis_backpt.h>
#include <bmsh3d/vis/bmsh3d_vis_edge.h>
#include <bmsh3d/vis/bmsh3d_vis_face.h>
#include <bmsh3d/vis/bmsh3d_vis_mesh.h>
#include <bmsh3d/vis/bmsh3d_vis_utils.h>
#include <bmsh3d/vis/bmsh3d_vis_vertex.h>

int main() { return 0; }
