#include <bnl/algo/bnl_legendre_polynomial.h>


int main() { return 0; }
