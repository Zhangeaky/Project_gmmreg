#include <testlib/testlib_register.h>


DECLARE(test_legendre_polynomial );

void
register_tests()
{

   REGISTER( test_legendre_polynomial );
}

DEFINE_MAIN;
