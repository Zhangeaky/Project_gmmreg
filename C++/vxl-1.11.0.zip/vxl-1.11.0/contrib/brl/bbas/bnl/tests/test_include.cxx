#include <bnl/bnl_parabolic_interpolator.h>
#include <bnl/bnl_quadratic_interpolator.h>

int main() { return 0; }
