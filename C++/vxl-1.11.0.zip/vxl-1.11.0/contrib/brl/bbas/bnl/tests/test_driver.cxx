#include <testlib/testlib_register.h>




void
register_tests()
{
  // no tests remaining
}

DEFINE_MAIN;



