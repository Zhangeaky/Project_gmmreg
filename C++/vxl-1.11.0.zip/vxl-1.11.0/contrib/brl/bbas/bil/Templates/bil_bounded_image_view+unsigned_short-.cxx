// Instantiation of bil_bounded_image_view<unsigned short>
#include <bil/bil_bounded_image_view.txx>
BIL_BOUNDED_IMAGE_VIEW_INSTANTIATE(unsigned short);
