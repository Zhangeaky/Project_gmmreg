#include <testlib/testlib_register.h>

DECLARE( test_bounded_image_view );



void register_tests()
{
  REGISTER( test_bounded_image_view );

}

DEFINE_MAIN;
