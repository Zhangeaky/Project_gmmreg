#include <bil/bil_bounded_image_view.h>
#include <bil/bil_math.h>

int main() { return 0; }
