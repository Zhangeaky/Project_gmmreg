#include <bil/algo/bil_detect_ridges.txx>
BIL_DETECT_RIDGES_INSTANTIATE(float);
