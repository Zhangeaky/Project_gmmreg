#include <bil/algo/bil_finite_second_differences.txx>
BIL_FINITE_SECOND_DIFFERENCES_INSTANTIATE(double);
