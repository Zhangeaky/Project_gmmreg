#include <testlib/testlib_test.h>

MAIN( test_bil_wshed2d )
{
  START ("2D Watershed Transform");

  SUMMARY();
}
