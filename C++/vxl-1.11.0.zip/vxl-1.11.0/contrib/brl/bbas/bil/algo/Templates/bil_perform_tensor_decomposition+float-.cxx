#include <bil/algo/bil_perform_tensor_decomposition.txx>
BIL_PERFORM_TENSOR_DECOMPOSITION_INSTANTIATE(float);
