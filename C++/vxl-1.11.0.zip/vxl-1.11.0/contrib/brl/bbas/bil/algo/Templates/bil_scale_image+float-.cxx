#include <bil/algo/bil_scale_image.txx>

BIL_SCALE_IMAGE_INSTANTIATE(float);
