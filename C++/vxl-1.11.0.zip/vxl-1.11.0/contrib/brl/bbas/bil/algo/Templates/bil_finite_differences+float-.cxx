#include <bil/algo/bil_finite_differences.txx>
BIL_FINITE_DIFFERENCES_INSTANTIATE(float);
