// This is brl/bbas/brdb/brdb_relation_sptr.h
#ifndef brdb_relation_sptr_h
#define brdb_relation_sptr_h
//:
// \file

class brdb_relation;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<brdb_relation> brdb_relation_sptr;


#endif // brdb_relation_sptr_h
