#include <brdb/brdb_value.txx>

BRDB_VALUE_INSTANTIATE(unsigned,"unsigned");
