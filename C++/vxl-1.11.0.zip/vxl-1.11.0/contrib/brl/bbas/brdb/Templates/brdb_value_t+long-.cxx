#include <brdb/brdb_value.txx>

BRDB_VALUE_INSTANTIATE(long,"long");
