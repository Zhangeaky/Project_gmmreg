#include <vcl_string.h>
#include <brdb/brdb_value.txx>

BRDB_VALUE_INSTANTIATE(vcl_string,"vcl_string");
