#include <brdb/brdb_value.txx>

BRDB_VALUE_INSTANTIATE(bool,"bool");
