#include <brdb/brdb_tuple.h>
#include <vbl/vbl_smart_ptr.txx>
 
VBL_SMART_PTR_INSTANTIATE(brdb_tuple);
