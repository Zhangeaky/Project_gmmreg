#include <brdb/brdb_value.h>
#include <vbl/vbl_smart_ptr.txx>


VBL_SMART_PTR_INSTANTIATE(brdb_value);
