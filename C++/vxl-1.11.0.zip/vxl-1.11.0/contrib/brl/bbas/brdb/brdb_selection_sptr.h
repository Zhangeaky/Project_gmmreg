// This is brl/bbas/brdb/brdb_selection_sptr.h
#ifndef brdb_selection_sptr_h
#define brdb_selection_sptr_h
//:
// \file

class brdb_selection;

#include <vbl/vbl_smart_ptr.h>

typedef vbl_smart_ptr<brdb_selection> brdb_selection_sptr;


#endif // brdb_selection_sptr_h
