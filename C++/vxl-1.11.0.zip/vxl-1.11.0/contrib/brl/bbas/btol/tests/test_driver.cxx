#include <testlib/testlib_register.h>

DECLARE(test_face_algs);

void
register_tests()
{
  REGISTER(test_face_algs);
}

DEFINE_MAIN;
