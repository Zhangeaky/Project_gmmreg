This is sources of expatpp v1.95.6 Beta copied from website
http://www.oofile.com.au/downloads.html#DownloadXML on 09/25/05.
